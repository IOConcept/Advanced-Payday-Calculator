from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/', methods=['POST'])
def calculate_pay():
    hourly_rate = float(request.form['hourly_rate'])
    non_overtime_hours = float(request.form['non_overtime_hours'])
    overtime_hours = float(request.form['overtime_hours'])
    incentive_percentage = float(request.form['incentive_percentage'])
    incentive_pay = float(request.form['incentive_pay'])

    # Calculate regular pay, overtime pay, and incentive pay
    regular_pay = hourly_rate * non_overtime_hours
    overtime_pay = hourly_rate * 1.5 * overtime_hours
    eligible_hours = (non_overtime_hours + overtime_hours) * (incentive_percentage / 100)
    incentive_pay = eligible_hours * incentive_pay

    # Calculate total pay
    total_pay = regular_pay + overtime_pay + incentive_pay

    return render_template('result.html', regular_pay=regular_pay, overtime_pay=overtime_pay, incentive_pay=incentive_pay, total_pay=total_pay)

if __name__ == '__main__':
    app.run(debug=True)
